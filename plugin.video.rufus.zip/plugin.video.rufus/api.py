import xbmc
import requests
import json
import os
import time
import hashlib
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed

TRAKT_CLIENT_ID   = '84a8bbd74b1f0b4c3efbdc6781d638b017533788410de3bfa519c5529d212cb3'
TMDB_API_KEY      = '4a0b7761c7c614f4d851c8b647961fab'
FANART_TV_API_KEY = 'YOUR_FANART_TV_API_KEY_HERE'  # <--- PUT YOUR KEY HERE

TRAKT_BASE       = 'https://api.trakt.tv'
TMDB_BASE        = 'https://api.themoviedb.org/3'
TMDB_IMAGE_BASE  = 'https://image.tmdb.org/t/p/w500'
TMDB_FANART_BASE = 'https://image.tmdb.org/t/p/w1280'

CACHE_DIR = os.path.join(
    os.path.expanduser('~'), 'AppData', 'Roaming', 'Kodi',
    'userdata', 'addon_data', 'plugin.video.rufus', 'cache'
)

CACHE_TTL_TRENDING = 21600
CACHE_TTL_GENRE    = 3600
CACHE_TTL_ITEM     = 86400

TMDB_MAX_WORKERS = 8
TRAKT_TIMEOUT    = 12
TMDB_TIMEOUT     = 10

_SESSION = requests.Session()
_SESSION.headers.update({'Accept-Encoding': 'gzip, deflate'})

_TRAKT_HEADERS = {
    'Content-Type':      'application/json',
    'trakt-api-version': '2',
    'trakt-api-key':     TRAKT_CLIENT_ID,
    'Accept-Encoding':   'gzip, deflate',
}

_MEM_CACHE      = {}
_MEM_CACHE_LOCK = Lock()

# ---------------------------------------------------------------------------
# TMDB Genre ID maps (static — these never change)
# ---------------------------------------------------------------------------

MOVIE_GENRES = {
    'Action':      28,
    'Adventure':   12,
    'Animation':   16,
    'Comedy':      35,
    'Crime':       80,
    'Documentary': 99,
    'Drama':       18,
    'Family':      10751,
    'Fantasy':     14,
    'History':     36,
    'Horror':      27,
    'Music':       10402,
    'Mystery':     9648,
    'Romance':     10749,
    'Sci-Fi':      878,
    'Thriller':    53,
    'War':         10752,
    'Western':     37,
}

TV_GENRES = {
    'Action & Adventure': 10759,
    'Animation':          16,
    'Comedy':             35,
    'Crime':              80,
    'Documentary':        99,
    'Drama':              18,
    'Family':             10751,
    'Kids':               10762,
    'Mystery':            9648,
    'News':               10763,
    'Reality':            10764,
    'Sci-Fi & Fantasy':   10765,
    'Soap':               10766,
    'Talk':               10767,
    'War & Politics':     10768,
    'Western':            37,
}


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _disk_path(key):
    return os.path.join(CACHE_DIR, hashlib.md5(key.encode()).hexdigest() + '.json')

def _ensure_cache_dir():
    if not os.path.exists(CACHE_DIR):
        os.makedirs(CACHE_DIR)

def cache_get(key, ttl=CACHE_TTL_TRENDING):
    with _MEM_CACHE_LOCK:
        entry = _MEM_CACHE.get(key)
        if entry:
            ts, data = entry
            if time.time() - ts < ttl:
                return data
            del _MEM_CACHE[key]
    try:
        path = _disk_path(key)
        if not os.path.exists(path):
            return None
        if time.time() - os.path.getmtime(path) > ttl:
            return None
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        with _MEM_CACHE_LOCK:
            _MEM_CACHE[key] = (time.time(), data)
        return data
    except Exception:
        return None

def cache_set(key, data):
    with _MEM_CACHE_LOCK:
        _MEM_CACHE[key] = (time.time(), data)
    try:
        _ensure_cache_dir()
        path = _disk_path(key)
        tmp  = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, separators=(',', ':'))
        os.replace(tmp, path)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def trakt_get(endpoint, params=None):
    url = TRAKT_BASE + endpoint
    try:
        r = _SESSION.get(url, headers=_TRAKT_HEADERS, params=params, timeout=TRAKT_TIMEOUT)
        if r.status_code == 200:
            return r.json()
        return []
    except Exception:
        return []

def tmdb_get(endpoint, params=None):
    p = {'api_key': TMDB_API_KEY}
    if params:
        p.update(params)
    url = TMDB_BASE + endpoint
    try:
        r = _SESSION.get(url, params=p, timeout=TMDB_TIMEOUT)
        if r.status_code == 200:
            return r.json()
        return {}
    except Exception:
        return {}

def get_fanart_logo(tmdb_id, media_type):
    if not FANART_TV_API_KEY or FANART_TV_API_KEY == 'YOUR_FANART_TV_API_KEY_HERE':
        return ''
    resource = 'movies' if media_type == 'movie' else 'tv'
    url = 'https://webservice.fanart.tv/v3/%s/%s?api_key=%s' % (resource, tmdb_id, FANART_TV_API_KEY)
    try:
        r = _SESSION.get(url, timeout=5)
        if r.status_code == 200:
            data = r.json()
            logos = data.get('hdclearlogo') or data.get('clearlogo')
            if logos:
                en_logos = [l['url'] for l in logos if l.get('lang') == 'en']
                return en_logos[0] if en_logos else logos[0]['url']
    except Exception:
        pass
    return ''


# ---------------------------------------------------------------------------
# TMDB detail fetchers
# ---------------------------------------------------------------------------

def _fetch_movie_detail(tmdb_id):
    ck  = 'tmdb_movie_%s' % tmdb_id
    hit = cache_get(ck, ttl=CACHE_TTL_ITEM)
    if hit:
        return hit
    data = tmdb_get('/movie/%s' % tmdb_id, params={'append_to_response': 'images', 'include_image_language': 'en,null'})
    if not data:
        return None
    clearlogo = get_fanart_logo(tmdb_id, 'movie')
    if not clearlogo:
        logos = [l for l in data.get('images', {}).get('logos', []) if l['file_path'].endswith('.png')]
        clearlogo = ('https://image.tmdb.org/t/p/original' + logos[0]['file_path']) if logos else ''
    result = {
        'poster':     (TMDB_IMAGE_BASE  + data['poster_path'])   if data.get('poster_path')   else '',
        'fanart':     (TMDB_FANART_BASE + data['backdrop_path'])  if data.get('backdrop_path') else '',
        'clearlogo':  clearlogo,
        'plot':       data.get('overview', ''),
        'year':       data.get('release_date', '')[:4] if data.get('release_date') else '',
        'rating':     str(data.get('vote_average', '')),
        'title':      data.get('title', ''),
        'tmdb_id':    str(tmdb_id),
        'media_type': 'movie',
        'runtime':    str(data.get('runtime', '')),
    }
    cache_set(ck, result)
    return result

def _fetch_show_detail(tmdb_id):
    ck  = 'tmdb_show_%s' % tmdb_id
    hit = cache_get(ck, ttl=CACHE_TTL_ITEM)
    if hit:
        return hit
    data = tmdb_get('/tv/%s' % tmdb_id, params={'append_to_response': 'images', 'include_image_language': 'en,null'})
    if not data:
        return None
    clearlogo = get_fanart_logo(tmdb_id, 'tvshow')
    if not clearlogo:
        logos = [l for l in data.get('images', {}).get('logos', []) if l['file_path'].endswith('.png')]
        clearlogo = ('https://image.tmdb.org/t/p/original' + logos[0]['file_path']) if logos else ''
    result = {
        'poster':     (TMDB_IMAGE_BASE  + data['poster_path'])   if data.get('poster_path')   else '',
        'fanart':     (TMDB_FANART_BASE + data['backdrop_path'])  if data.get('backdrop_path') else '',
        'clearlogo':  clearlogo,
        'plot':       data.get('overview', ''),
        'year':       data.get('first_air_date', '')[:4] if data.get('first_air_date') else '',
        'rating':     str(data.get('vote_average', '')),
        'title':      data.get('name', ''),
        'tmdb_id':    str(tmdb_id),
        'media_type': 'tvshow',
        'seasons':    str(data.get('number_of_seasons', '')),
    }
    cache_set(ck, result)
    return result

def _parallel_fetch(tmdb_ids, fetch_func):
    results = [None] * len(tmdb_ids)
    if not tmdb_ids:
        return results
    with ThreadPoolExecutor(max_workers=TMDB_MAX_WORKERS) as pool:
        futures = {pool.submit(fetch_func, tid): i for i, tid in enumerate(tmdb_ids)}
        for future in as_completed(futures):
            try:
                results[futures[future]] = future.result()
            except Exception:
                pass
    return results

def _merge(trakt_item, tmdb_detail, ids, tmdb_id, media_type):
    d = tmdb_detail or {}
    return {
        'title':      trakt_item.get('title', d.get('title', 'Unknown')),
        'year':       str(trakt_item.get('year', d.get('year', ''))),
        'plot':       trakt_item.get('overview') or d.get('plot', ''),
        'rating':     str(trakt_item.get('rating', d.get('rating', ''))),
        'poster':     d.get('poster', ''),
        'fanart':     d.get('fanart', ''),
        'clearlogo':  d.get('clearlogo', ''),
        'tmdb_id':    str(tmdb_id),
        'imdb_id':    ids.get('imdb', ''),
        'trakt_id':   str(ids.get('trakt', '')),
        'slug':       ids.get('slug', ''),
        'media_type': media_type,
        'seasons':    d.get('seasons', ''),
        'runtime':    d.get('runtime', ''),
    }


# ---------------------------------------------------------------------------
# Movies
# ---------------------------------------------------------------------------

def get_trending_movies(limit=25):
    cached = cache_get('trending_movies')
    if cached:
        return cached
    data    = trakt_get('/movies/trending', params={'limit': limit, 'extended': 'full'})
    raw     = [(i['movie'], i['movie']['ids'], i['movie']['ids']['tmdb']) for i in data if i.get('movie', {}).get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_movie_detail)
    movies  = [_merge(m, d, ids, tid, 'movie') for (m, ids, tid), d in zip(raw, details) if d]
    cache_set('trending_movies', movies)
    return movies

def get_popular_movies(limit=25):
    cached = cache_get('popular_movies')
    if cached:
        return cached
    data    = trakt_get('/movies/popular', params={'limit': limit, 'extended': 'full'})
    raw     = [(m, m['ids'], m['ids']['tmdb']) for m in data if m.get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_movie_detail)
    movies  = [_merge(m, d, ids, tid, 'movie') for (m, ids, tid), d in zip(raw, details) if d]
    cache_set('popular_movies', movies)
    return movies

def get_anticipated_movies(limit=25):
    cached = cache_get('anticipated_movies')
    if cached:
        return cached
    data    = trakt_get('/movies/anticipated', params={'limit': limit, 'extended': 'full'})
    raw     = [(i['movie'], i['movie']['ids'], i['movie']['ids']['tmdb']) for i in data if i.get('movie', {}).get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_movie_detail)
    movies  = [_merge(m, d, ids, tid, 'movie') for (m, ids, tid), d in zip(raw, details) if d]
    cache_set('anticipated_movies', movies)
    return movies

def get_boxoffice_movies(limit=25):
    cached = cache_get('boxoffice_movies')
    if cached:
        return cached
    data    = trakt_get('/movies/boxoffice', params={'extended': 'full'})
    raw     = [(i['movie'], i['movie']['ids'], i['movie']['ids']['tmdb']) for i in data[:limit] if i.get('movie', {}).get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_movie_detail)
    movies  = [_merge(m, d, ids, tid, 'movie') for (m, ids, tid), d in zip(raw, details) if d]
    cache_set('boxoffice_movies', movies)
    return movies

def get_now_playing_movies(limit=25):
    cached = cache_get('now_playing_movies')
    if cached:
        return cached
    data   = tmdb_get('/movie/now_playing', params={'language': 'en-US', 'page': 1})
    movies = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        movies.append({
            'title':      item.get('title', 'Unknown'),
            'year':       item.get('release_date', '')[:4] if item.get('release_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    '',
            'media_type': 'movie',
            'runtime':    '',
        })
    cache_set('now_playing_movies', movies)
    return movies

def get_upcoming_movies(limit=25):
    cached = cache_get('upcoming_movies')
    if cached:
        return cached
    data   = tmdb_get('/movie/upcoming', params={'language': 'en-US', 'page': 1})
    movies = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        movies.append({
            'title':      item.get('title', 'Unknown'),
            'year':       item.get('release_date', '')[:4] if item.get('release_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    '',
            'media_type': 'movie',
            'runtime':    '',
        })
    cache_set('upcoming_movies', movies)
    return movies

def get_top_rated_movies(limit=25):
    cached = cache_get('top_rated_movies')
    if cached:
        return cached
    data   = tmdb_get('/movie/top_rated', params={'language': 'en-US', 'page': 1})
    movies = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        movies.append({
            'title':      item.get('title', 'Unknown'),
            'year':       item.get('release_date', '')[:4] if item.get('release_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    '',
            'media_type': 'movie',
            'runtime':    '',
        })
    cache_set('top_rated_movies', movies)
    return movies

def get_movies_by_genre(genre_id, limit=25):
    cache_key = 'genre_movies_%s' % genre_id
    cached    = cache_get(cache_key, ttl=CACHE_TTL_GENRE)
    if cached:
        return cached
    data   = tmdb_get('/discover/movie', params={'with_genres': genre_id, 'sort_by': 'popularity.desc', 'per_page': limit})
    movies = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        movies.append({
            'title':      item.get('title', 'Unknown'),
            'year':       item.get('release_date', '')[:4] if item.get('release_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'media_type': 'movie',
            'runtime':    '',
        })
    cache_set(cache_key, movies)
    return movies


# ---------------------------------------------------------------------------
# TV Shows
# ---------------------------------------------------------------------------

def get_trending_shows(limit=25):
    cached = cache_get('trending_shows')
    if cached:
        return cached
    data    = trakt_get('/shows/trending', params={'limit': limit, 'extended': 'full'})
    raw     = [(i['show'], i['show']['ids'], i['show']['ids']['tmdb']) for i in data if i.get('show', {}).get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_show_detail)
    shows   = [_merge(s, d, ids, tid, 'tvshow') for (s, ids, tid), d in zip(raw, details) if d]
    cache_set('trending_shows', shows)
    return shows

def get_popular_shows(limit=25):
    cached = cache_get('popular_shows')
    if cached:
        return cached
    data    = trakt_get('/shows/popular', params={'limit': limit, 'extended': 'full'})
    raw     = [(s, s['ids'], s['ids']['tmdb']) for s in data if s.get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_show_detail)
    shows   = [_merge(s, d, ids, tid, 'tvshow') for (s, ids, tid), d in zip(raw, details) if d]
    cache_set('popular_shows', shows)
    return shows

def get_anticipated_shows(limit=25):
    cached = cache_get('anticipated_shows')
    if cached:
        return cached
    data    = trakt_get('/shows/anticipated', params={'limit': limit, 'extended': 'full'})
    raw     = [(i['show'], i['show']['ids'], i['show']['ids']['tmdb']) for i in data if i.get('show', {}).get('ids', {}).get('tmdb')]
    details = _parallel_fetch([r[2] for r in raw], _fetch_show_detail)
    shows   = [_merge(s, d, ids, tid, 'tvshow') for (s, ids, tid), d in zip(raw, details) if d]
    cache_set('anticipated_shows', shows)
    return shows

def get_airing_today_shows(limit=25):
    cached = cache_get('airing_today_shows')
    if cached:
        return cached
    data  = tmdb_get('/tv/airing_today', params={'language': 'en-US', 'page': 1})
    shows = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        shows.append({
            'title':      item.get('name', 'Unknown'),
            'year':       item.get('first_air_date', '')[:4] if item.get('first_air_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    '',
            'media_type': 'tvshow',
            'seasons':    '',
        })
    cache_set('airing_today_shows', shows)
    return shows

def get_on_the_air_shows(limit=25):
    cached = cache_get('on_the_air_shows')
    if cached:
        return cached
    data  = tmdb_get('/tv/on_the_air', params={'language': 'en-US', 'page': 1})
    shows = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        shows.append({
            'title':      item.get('name', 'Unknown'),
            'year':       item.get('first_air_date', '')[:4] if item.get('first_air_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    '',
            'media_type': 'tvshow',
            'seasons':    '',
        })
    cache_set('on_the_air_shows', shows)
    return shows

def get_top_rated_shows(limit=25):
    cached = cache_get('top_rated_shows')
    if cached:
        return cached
    data  = tmdb_get('/tv/top_rated', params={'language': 'en-US', 'page': 1})
    shows = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        shows.append({
            'title':      item.get('name', 'Unknown'),
            'year':       item.get('first_air_date', '')[:4] if item.get('first_air_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    '',
            'media_type': 'tvshow',
            'seasons':    '',
        })
    cache_set('top_rated_shows', shows)
    return shows

def get_shows_by_genre(genre_id, limit=25):
    cache_key = 'genre_shows_%s' % genre_id
    cached    = cache_get(cache_key, ttl=CACHE_TTL_GENRE)
    if cached:
        return cached
    data  = tmdb_get('/discover/tv', params={'with_genres': genre_id, 'sort_by': 'popularity.desc', 'per_page': limit})
    shows = []
    for item in data.get('results', [])[:limit]:
        tmdb_id = item.get('id')
        if not tmdb_id:
            continue
        shows.append({
            'title':      item.get('name', 'Unknown'),
            'year':       item.get('first_air_date', '')[:4] if item.get('first_air_date') else '',
            'plot':       item.get('overview', ''),
            'rating':     str(item.get('vote_average', '')),
            'poster':     (TMDB_IMAGE_BASE  + item['poster_path'])   if item.get('poster_path')   else '',
            'fanart':     (TMDB_FANART_BASE + item['backdrop_path'])  if item.get('backdrop_path') else '',
            'clearlogo':  '',
            'tmdb_id':    str(tmdb_id),
            'media_type': 'tvshow',
            'seasons':    '',
        })
    cache_set(cache_key, shows)
    return shows


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search_all(query, limit=25):
    data      = trakt_get('/search/movie,show', params={'query': query, 'limit': limit, 'extended': 'full'})
    movie_raw = [(i['movie'], i['movie']['ids'], i['movie']['ids']['tmdb']) for i in data if i.get('type') == 'movie' and i.get('movie', {}).get('ids', {}).get('tmdb')]
    show_raw  = [(i['show'],  i['show']['ids'],  i['show']['ids']['tmdb'])  for i in data if i.get('type') == 'show'  and i.get('show',  {}).get('ids', {}).get('tmdb')]

    results = []
    all_raw = [('movie', r) for r in movie_raw] + [('show', r) for r in show_raw]
    if not all_raw:
        return results

    fetch_fn = {'movie': _fetch_movie_detail, 'show': _fetch_show_detail}
    with ThreadPoolExecutor(max_workers=TMDB_MAX_WORKERS) as pool:
        futures = {pool.submit(fetch_fn[kind], r[2]): (kind, r) for kind, r in all_raw}
        for future in as_completed(futures):
            kind, (media, ids, tmdb_id) = futures[future]
            try:
                detail = future.result()
            except Exception:
                detail = None
            results.append(_merge(media, detail, ids, tmdb_id, 'movie' if kind == 'movie' else 'tvshow'))

    return results
