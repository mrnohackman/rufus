import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xml.etree.ElementTree as ET

try:
    from urllib.parse import parse_qsl, urlencode, quote_plus, urlparse
except ImportError:
    from urlparse import parse_qsl, urlparse
    from urllib import urlencode, quote_plus

HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def build_url(params):
    return BASE_URL + '?' + urlencode(params)


def _fenlight_movie_url(tmdb_id, imdb_id, title, year):
    return (
        'plugin://plugin.video.fenlight/?mode=playback.media'
        '&media_type=movie&tmdb_id=%s&imdb_id=%s&title=%s&year=%s'
    ) % (tmdb_id, imdb_id, quote_plus(title), year)


def _fenlight_show_url(tmdb_id, imdb_id, title, year):
    return (
        'plugin://plugin.video.fenlight/?mode=build_season_list'
        '&tmdb_id=%s&imdb_id=%s&title=%s&year=%s&media_type=tvshow'
    ) % (tmdb_id, imdb_id, quote_plus(title), year)


# ---------------------------------------------------------------------------
# List-item builders
# ---------------------------------------------------------------------------

def add_movie_item(movie):
    title  = movie.get('title', 'Unknown')
    year   = movie.get('year', '')
    label  = '%s (%s)' % (title, year) if year else title

    bottom_label = str(year)
    runtime = movie.get('runtime', '')
    if runtime and runtime != '0':
        bottom_label += ' \u2022 %s min' % runtime

    li = xbmcgui.ListItem(label)
    li.setArt({
        'poster':    movie.get('poster', ''),
        'fanart':    movie.get('fanart', ''),
        'clearlogo': movie.get('clearlogo', ''),
        'thumb':     movie.get('poster', ''),
    })
    li.setInfo('video', {
        'title':     title,
        'year':      int(year) if year and year.isdigit() else 0,
        'plot':      movie.get('plot', ''),
        'rating':    float(movie.get('rating', 0)) if movie.get('rating') else 0,
        'mediatype': 'movie',
    })
    li.setProperty('BottomLabel', bottom_label)
    li.setProperty('IsPlayable', 'false')
    plugin_url = _fenlight_movie_url(
        movie.get('tmdb_id', ''),
        movie.get('imdb_id', ''),
        title,
        year,
    )
    # FavAction drives ALL panel onclicks — movies need RunPlugin, not ActivateWindow
    li.setProperty('FavAction', 'RunPlugin(%s)' % plugin_url)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)


def add_show_item(show):
    title   = show.get('title', 'Unknown')
    year    = show.get('year', '')
    tmdb_id = show.get('tmdb_id', '')
    imdb_id = show.get('imdb_id', '')
    label   = '%s (%s)' % (title, year) if year else title

    bottom_label = str(year)
    seasons = show.get('seasons', '')
    if seasons and seasons != '0':
        s_text = 'Season' if str(seasons) == '1' else 'Seasons'
        bottom_label += ' \u2022 %s %s' % (seasons, s_text)

    li = xbmcgui.ListItem(label)
    li.setArt({
        'poster':    show.get('poster', ''),
        'fanart':    show.get('fanart', ''),
        'clearlogo': show.get('clearlogo', ''),
        'thumb':     show.get('poster', ''),
    })
    li.setInfo('video', {
        'title':     title,
        'year':      int(year) if year and year.isdigit() else 0,
        'plot':      show.get('plot', ''),
        'rating':    float(show.get('rating', 0)) if show.get('rating') else 0,
        'mediatype': 'tvshow',
    })
    li.setProperty('BottomLabel', bottom_label)
    fenlight_url = _fenlight_show_url(tmdb_id, imdb_id, title, year)
    # FavAction drives ALL panel onclicks — shows need ActivateWindow(Videos,...) to open as directory
    li.setProperty('FavAction', 'ActivateWindow(Videos,"%s",return)' % fenlight_url)
    xbmcplugin.addDirectoryItem(HANDLE, fenlight_url, li, True)


# ---------------------------------------------------------------------------
# Views
# ---------------------------------------------------------------------------

def show_main_menu():
    items = [
        ('Trending Movies', build_url({'mode': 'trending'}),       True),
        ('Popular Movies',  build_url({'mode': 'popular'}),        True),
        ('My Favourites',   build_url({'mode': 'favorites'}),      True),
    ]
    for label, url, is_folder in items:
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': 'DefaultMovies.png'})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)
    xbmcplugin.endOfDirectory(HANDLE)


def show_trending():
    from api import get_trending_movies
    xbmcplugin.setContent(HANDLE, 'movies')
    for movie in get_trending_movies(limit=25):
        add_movie_item(movie)
    xbmcplugin.endOfDirectory(HANDLE)


def show_popular():
    from api import get_popular_movies
    xbmcplugin.setContent(HANDLE, 'movies')
    for movie in get_popular_movies(limit=25):
        add_movie_item(movie)
    xbmcplugin.endOfDirectory(HANDLE)


def show_trending_shows():
    from api import get_trending_shows
    xbmcplugin.setContent(HANDLE, 'tvshows')
    for show in get_trending_shows(limit=25):
        add_show_item(show)
    xbmcplugin.endOfDirectory(HANDLE)


def show_popular_shows():
    from api import get_popular_shows
    xbmcplugin.setContent(HANDLE, 'tvshows')
    for show in get_popular_shows(limit=25):
        add_show_item(show)
    xbmcplugin.endOfDirectory(HANDLE)


def show_movies_by_genre(params):
    from api import get_movies_by_genre
    xbmcplugin.setContent(HANDLE, 'movies')
    for movie in get_movies_by_genre(params.get('genre_id', ''), limit=25):
        add_movie_item(movie)
    xbmcplugin.endOfDirectory(HANDLE)


def show_shows_by_genre(params):
    from api import get_shows_by_genre
    xbmcplugin.setContent(HANDLE, 'tvshows')
    for show in get_shows_by_genre(params.get('genre_id', ''), limit=25):
        add_show_item(show)
    xbmcplugin.endOfDirectory(HANDLE)


def show_search(query=None):
    from api import search_all
    if not query:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    xbmcplugin.setContent(HANDLE, 'videos')
    results = search_all(query, limit=25)
    if results:
        for item in results:
            if item.get('media_type') == 'tvshow':
                add_show_item(item)
            else:
                add_movie_item(item)
    else:
        li = xbmcgui.ListItem('No results found for: %s' % query)
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------------------
# Favourites helpers
# ---------------------------------------------------------------------------

def _parse_fav_action(action):
    """Return (tmdb_id, media_type) from a normalised action string."""
    import re
    tmdb_id    = ''
    media_type = 'tvshow'

    m = re.search(r'tmdb_id=(\d+)', action)
    if m:
        tmdb_id = m.group(1)

    m = re.search(r'media_type=(movie|tvshow)', action)
    if m:
        media_type = m.group(1)
    else:
        if 'build_season_list' in action:
            media_type = 'tvshow'
        elif 'playback.media' in action:
            media_type = 'movie'

    return tmdb_id, media_type


def _normalize_fav_action(action):
    """
    Normalise any favourite action into a ready-to-execute builtin string:

    - Movies  -> RunPlugin(plugin://plugin.video.fenlight/?mode=playback.media...)
    - TV Shows -> ActivateWindow(Videos,"plugin://plugin.video.fenlight/?mode=build_season_list...",return)

    Handles three input formats:
    1. Old Rufus play URLs  (mode=play)
    2. ActivateWindow with wrong window number (10000 instead of Videos)
    3. Already correct ActivateWindow(Videos,...) or ActivateWindow(10025,...) calls
    """
    import re

    # --- Case 1: Old Rufus play URL saved as a favourite ---
    m = re.search(r'"(plugin://plugin\.video\.rufus/\?[^"]*mode=play[^"]*)"', action)
    if m:
        parsed     = dict(parse_qsl(urlparse(m.group(1)).query))
        title      = parsed.get('title', '')
        year       = parsed.get('year', '')
        tmdb_id    = parsed.get('tmdb_id', '')
        imdb_id    = parsed.get('imdb_id', '')
        media_type = parsed.get('media_type', 'movie')

        if media_type == 'tvshow':
            plugin_url = _fenlight_show_url(tmdb_id, imdb_id, title, year)
            result = 'ActivateWindow(Videos,"%s",return)' % plugin_url
        else:
            plugin_url = _fenlight_movie_url(tmdb_id, imdb_id, title, year)
            result = 'RunPlugin(%s)' % plugin_url

        xbmc.log('RUFUS_DEBUG: Converted Rufus fav -> %s' % result, xbmc.LOGINFO)
        return result

    # --- Case 2: ActivateWindow with any numeric window ID ---
    # Fix the window number to use the name "Videos" (works across Kodi versions)
    m = re.search(r'ActivateWindow\(\d+,"(plugin://[^"]+)"', action)
    if m:
        plugin_url = m.group(1)
        # Decide correct builtin based on what the URL does
        if 'build_season_list' in plugin_url or 'media_type=tvshow' in plugin_url:
            result = 'ActivateWindow(Videos,"%s",return)' % plugin_url
        else:
            result = 'RunPlugin(%s)' % plugin_url
        xbmc.log('RUFUS_DEBUG: Normalised ActivateWindow fav -> %s' % result, xbmc.LOGINFO)
        return result

    # --- Case 3: Already a correct ActivateWindow(Videos,...) ---
    # Just return as-is; it's already the right format
    return action


# ---------------------------------------------------------------------------
# Favourites view
# ---------------------------------------------------------------------------

def show_my_favorites():
    """
    Read favourites.xml, enrich each entry with full TMDB metadata and
    display as list items.

    KEY FIX: each list item's URL *is* the Fenlight plugin:// URL.
    The skin just needs a normal onclick (the panel's existing
    ActivateWindow(Videos,...,return) or RunPlugin) — no custom FavAction
    property needed.  The skin XML already does:
        <onclick>ActivateWindow(Videos,$INFO[ListItem.FileNameAndPath],return)</onclick>
    That works perfectly when FileNameAndPath is a plugin:// URL.
    """
    from api import _fetch_movie_detail, _fetch_show_detail
    from concurrent.futures import ThreadPoolExecutor, as_completed

    xbmcplugin.setContent(HANDLE, 'videos')

    fav_path  = 'special://profile/favourites.xml'
    raw_items = []

    try:
        if not xbmcvfs.exists(fav_path):
            xbmc.log('RUFUS_DEBUG: favourites.xml not found', xbmc.LOGWARNING)
        else:
            with xbmcvfs.File(fav_path) as f:
                raw = f.read()
            root = ET.fromstring(raw)
            for fav in root.findall('favourite'):
                name   = fav.get('name', 'Unknown')
                thumb  = fav.get('thumb', '')
                action = (fav.text or '').strip()
                if not action:
                    continue

                # Normalise to a ready-to-execute builtin string
                norm_action = _normalize_fav_action(action)
                tmdb_id, media_type = _parse_fav_action(norm_action)

                raw_items.append({
                    'name':       name,
                    'thumb':      thumb,
                    'action':     norm_action,
                    'tmdb_id':    tmdb_id,
                    'media_type': media_type,
                })
            xbmc.log('RUFUS_DEBUG: Loaded %d favourites from XML' % len(raw_items), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('RUFUS_DEBUG: Error reading favourites.xml: %s' % str(e), xbmc.LOGERROR)

    if not raw_items:
        li = xbmcgui.ListItem('No favourites found')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Fetch full TMDB metadata in parallel
    details   = [None] * len(raw_items)
    fetchable = [(i, r) for i, r in enumerate(raw_items) if r['tmdb_id']]

    if fetchable:
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = {}
            for i, r in fetchable:
                fn = _fetch_show_detail if r['media_type'] == 'tvshow' else _fetch_movie_detail
                futures[pool.submit(fn, r['tmdb_id'])] = i
            for future in as_completed(futures):
                idx = futures[future]
                try:
                    details[idx] = future.result()
                except Exception as e:
                    xbmc.log('RUFUS_DEBUG: TMDB fetch error for fav %d: %s' % (idx, str(e)), xbmc.LOGWARNING)

    # Build list items
    for i, raw in enumerate(raw_items):
        name       = raw['name']
        thumb      = raw['thumb']
        action     = raw['action']   # full builtin: RunPlugin(...) or ActivateWindow(Videos,...)
        media_type = raw['media_type']
        detail     = details[i] or {}

        poster    = detail.get('poster')    or thumb
        fanart    = detail.get('fanart')    or thumb
        clearlogo = detail.get('clearlogo') or ''
        plot      = detail.get('plot',   '')
        year      = detail.get('year',   '')
        rating    = detail.get('rating', '')
        title     = detail.get('title',  name)

        label = '%s (%s)' % (title, year) if year else title

        li = xbmcgui.ListItem(label)
        li.setArt({
            'poster':    poster,
            'thumb':     poster,
            'fanart':    fanart,
            'clearlogo': clearlogo,
        })
        li.setInfo('video', {
            'title':     title,
            'plot':      plot,
            'year':      int(year) if year and year.isdigit() else 0,
            'rating':    float(rating) if rating else 0,
            'mediatype': 'tvshow' if media_type == 'tvshow' else 'movie',
        })
        li.setProperty('IsPlayable', 'false')
        # FavAction holds the correct builtin per type:
        #   movies -> RunPlugin(plugin://plugin.video.fenlight/...)
        #   shows  -> ActivateWindow(Videos,"plugin://plugin.video.fenlight/...",return)
        # The skin onclick="$INFO[ListItem.Property(FavAction)]" fires this directly.
        li.setProperty('FavAction', action)

        # is_folder=True for shows so Kodi knows it's a directory.
        xbmcplugin.addDirectoryItem(HANDLE, '', li, media_type == 'tvshow')

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------------------
# play_media — kept for backwards compat with any saved Rufus URLs
# ---------------------------------------------------------------------------

def play_media(params):
    title      = params.get('title', '')
    year       = params.get('year', '0')
    tmdb_id    = params.get('tmdb_id', '')
    imdb_id    = params.get('imdb_id', '')
    media_type = params.get('media_type', 'movie')
    xbmc.log('Rufus: Playing - %s (%s) tmdb=%s type=%s' % (title, year, tmdb_id, media_type), xbmc.LOGINFO)

    if media_type == 'tvshow':
        plugin_url = _fenlight_show_url(tmdb_id, imdb_id, title, year)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % plugin_url)
    else:
        plugin_url = _fenlight_movie_url(tmdb_id, imdb_id, title, year)
        # RunPlugin is the correct call for a playback URL — it doesn't try
        # to open a directory window, so it works regardless of Kodi version.
        xbmc.executebuiltin('RunPlugin(%s)' % plugin_url)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    mode   = params.get('mode', 'main')

    if   mode == 'main':           show_main_menu()
    elif mode == 'trending':       show_trending()
    elif mode == 'popular':        show_popular()
    elif mode == 'trending_shows': show_trending_shows()
    elif mode == 'popular_shows':  show_popular_shows()
    elif mode == 'movies_by_genre':show_movies_by_genre(params)
    elif mode == 'shows_by_genre': show_shows_by_genre(params)
    elif mode == 'search':         show_search(query=params.get('query'))
    elif mode == 'favorites':      show_my_favorites()
    elif mode == 'play':           play_media(params)
    else:                          show_main_menu()


if __name__ == '__main__':
    router()
